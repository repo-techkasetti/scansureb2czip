import { useCallback, useEffect, useState } from "react";

const useFetch = <T>(
  fetchFn: () => Promise<T>,
  auto = true
) => {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const refetch = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await fetchFn();
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err : new Error("Unknown error"));
    } finally {
      setLoading(false);
    }
  }, [fetchFn]);

  useEffect(() => {
    if (auto) {
      refetch();
    }
  }, [auto, refetch]);

  return { data, loading, error, refetch };
};

export default useFetch;