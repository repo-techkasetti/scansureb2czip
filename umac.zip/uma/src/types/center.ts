export type Test = {
  id: string;
  testKeyword: string;
  durationMinutes: number;
  price: number;
};

export type Modality = {
  id: string;
  name: string;
  code: string;
  tests: Test[];
};

export type CenterDetail = {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  rating: number;
  modalities: Modality[];
};