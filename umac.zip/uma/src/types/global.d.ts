export { };

declare global {
  var userId: string | undefined;
}