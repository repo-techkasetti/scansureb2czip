export async function fetchCenterDetail(centerId: string) {
  console.log("fetchCenterDetail called with:", centerId);

  //
  // const IP_ADDRESS='192.168.1.68';
  const IP_ADDRESS=process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS;//--
  //
  const BASE_URL = `http://${IP_ADDRESS}:3000`; // change if needed--

  // const BASE_URL = process.env.EXPO_PUBLIC_NGROK_URL;

  console.log('CDPFURL: ',`${BASE_URL}/center/${centerId}`);

  // const res = await fetch(`http://${process.env.IP_ADDRESS}:3000/center/${centerId}`);
  // const res = await fetch(`http://192.168.137.1:3000/center/${centerId}`);
  const res = await fetch(`${BASE_URL}/center/${centerId}`);



  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || "Failed to fetch center detail");
  }

  const data = await res.json();
  console.log("CENTER API RESPONSE:", data);

  return data;
}