//
// const IP_ADDRESS='192.168.1.68';
const IP_ADDRESS=process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS;
//
const MY_BASE_URL = `http://${IP_ADDRESS}:3000`; // change if needed


const BASE_URL = `${MY_BASE_URL}/api`;

export const sendOtp = async (phone: string) => {

  const res = await fetch(`${BASE_URL}/auth/send-otp`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone })
  });

  return res.json();
};

export const verifyOtp = async (phone: string, otp: string) => {

  const res = await fetch(`${BASE_URL}/auth/verify-otp`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone, otp })
  });

  return res.json();
};