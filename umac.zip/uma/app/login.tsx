import { router, useLocalSearchParams } from "expo-router";
import { useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { sendOtp, verifyOtp } from "../src/lib/authApi";

export default function LoginScreen() {

  const params = useLocalSearchParams();

  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"phone" | "otp">("phone");

  const handleSendOtp = async () => {
    try {
      await sendOtp(phone);
      setStep("otp");
    } catch (e) {
      console.log("OTP send error", e);
    }
  };

  const handleVerifyOtp = async () => {
    try {

      const res = await verifyOtp(phone, otp);

      global.userId = res.userId;

      router.replace({
        pathname: "/patient",
        params
      });

    } catch (e) {
      console.log("OTP verify error", e);
    }
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>

      <Text style={{ fontSize: 22, fontWeight: "bold" }}>
        Login
      </Text>

      {step === "phone" && (
        <>
          <TextInput
            placeholder="Phone Number"
            value={phone}
            onChangeText={setPhone}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 20
            }}
          />

          <Pressable
            onPress={handleSendOtp}
            style={{
              marginTop: 20,
              backgroundColor: "blue",
              padding: 12
            }}
          >
            <Text style={{ color: "white", textAlign: "center" }}>
              Send OTP
            </Text>
          </Pressable>
        </>
      )}

      {step === "otp" && (
        <>
          <TextInput
            placeholder="Enter OTP"
            value={otp}
            onChangeText={setOtp}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 20
            }}
          />

          <Pressable
            onPress={handleVerifyOtp}
            style={{
              marginTop: 20,
              backgroundColor: "green",
              padding: 12
            }}
          >
            <Text style={{ color: "white", textAlign: "center" }}>
              Verify OTP
            </Text>
          </Pressable>
        </>
      )}

    </View>
  );
}