// import { router } from "expo-router";
import { router, useLocalSearchParams } from "expo-router";
import { useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";

export default function AadhaarScreen() {

  const params = useLocalSearchParams();

  const [aadhaar, setAadhaar] = useState("");

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  const [step, setStep] = useState<"aadhaar" | "register">("aadhaar");

  const handleCheck = async () => {

    const res = await fetch(
      `http://localhost:3001/api/patient/aadhaar/${aadhaar}`
    );

    const data = await res.json();
    console.log("Registered patient with UPI:", data.data.upi_id);
    if (data.status === "found") {

    //   global.upi_id = data.data.upi_id;

    //   router.replace("/patient");//w1
    router.replace({ 
        pathname: "/patient",
        params: {
          ...params,
            upi_id: data.data.upi_id,
        },
     });

    } else {

      setStep("register");

    }

  };

  const handleRegister = async () => {

    const res = await fetch(
      "http://localhost:3001/api/patient/register",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          aadhaar_no: aadhaar,
          name,
          phone
        })
      }
    );

    const data = await res.json();

    // global.upi_id = data.data.upi_id;
    console.log("Registered patient with UPI:", data.data.upi_id);
    // router.replace("/patient");//w1
    router.replace({ 
        pathname: "/patient",
        params: {
            upi_id: data.data.upi_id,
        },
     });

  };

  return (
    <View style={{ flex: 1, padding: 20 }}>

      <Text style={{ fontSize: 22, fontWeight: "bold" }}>
        Universal Patient Identification
      </Text>

      {step === "aadhaar" && (
        <>
          <TextInput
            maxLength={12}
            keyboardType="numeric"
            placeholder="Enter Aadhaar"
            value={aadhaar}
            onChangeText={setAadhaar}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 20
            }}
          />

          <Pressable
            onPress={handleCheck}
            style={{
              marginTop: 20,
              backgroundColor: "blue",
              padding: 12
            }}
          >
            <Text style={{ color: "white", textAlign: "center" }}>
              Check Patient
            </Text>
          </Pressable>
        </>
      )}

      {step === "register" && (
        <>
          <Text style={{ marginTop: 20 }}>
            Patient not found. Register.
          </Text>

          <TextInput
            placeholder="Name"
            value={name}
            onChangeText={setName}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 10
            }}
          />

          <TextInput
            placeholder="Phone"
            value={phone}
            onChangeText={setPhone}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 10
            }}
          />

          <Pressable
            onPress={handleRegister}
            style={{
              marginTop: 20,
              backgroundColor: "green",
              padding: 12
            }}
          >
            <Text style={{ color: "white", textAlign: "center" }}>
              Register Patient
            </Text>
          </Pressable>
        </>
      )}

    </View>
  );
}