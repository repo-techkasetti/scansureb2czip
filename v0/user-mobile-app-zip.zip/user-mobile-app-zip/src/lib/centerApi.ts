export async function fetchCenterDetail(centerId: string) {
  console.log("fetchCenterDetail called with:", centerId);

  // const MY_BASE_URL = `http://localhost:3000`;
  const BASE_URL = `http://${process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS_LH}:${process.env.EXPO_PUBLIC_PORT_0}`;

  console.log('CDPFURL: ',`${BASE_URL}/center/${centerId}`);
  // const res = await fetch(`http://192.168.137.1:3000/center/${centerId}`);
  const res = await fetch(`${BASE_URL}/center/${centerId}`);



  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || "Failed to fetch center detail");
  }

  const data = await res.json();
  console.log("CENTER API RESPONSE:", data);

  return data;
}