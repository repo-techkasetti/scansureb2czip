// const MY_BASE_URL = `http://localhost:3000`;
  const BASE_URL = `http://${process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS_LH}:${process.env.EXPO_PUBLIC_PORT_0}`;

export const createBooking = async (payload: any) => {
  const res = await fetch(`${BASE_URL}/api/bookings/create`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  return res.json();
};

export const verifyPayment = async (payload: any) => {
  const res = await fetch(`${BASE_URL}/api/payment/verify`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  return res.json();
};