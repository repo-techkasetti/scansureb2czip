// const MY_BASE_URL = `http://localhost:3000`;
const MY_BASE_URL = `http://${process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS_LH}:${process.env.EXPO_PUBLIC_PORT_0}`;
const BASE_URL = `${MY_BASE_URL}/api`;

export const sendOtp = async (phone: string) => {

  const res = await fetch(`${BASE_URL}/auth/send-otp`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone })
  });

  return res.json();
};

export const verifyOtp = async (phone: string, otp: string) => {

  const res = await fetch(`${BASE_URL}/auth/verify-otp`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone, otp })
  });

  return res.json();
};