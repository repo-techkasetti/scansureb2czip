import { SearchRequest, SearchResponse } from "../types/search";

// const MY_BASE_URL = `http://localhost:3000`;
const BASE_URL = `http://${process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS_LH}:${process.env.EXPO_PUBLIC_PORT_0}`;

export const fetchSearchResults = async (
  
  payload: SearchRequest
): Promise<SearchResponse> => {
  console.log("Rendering Center component 3");
  const response = await fetch(`${BASE_URL}/api/search`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(error || "Search failed");
  }

  return response.json();
};

export async function fetchCenterDetail(centerId: string) {
  console.log("fetchCenterDetail");
  const res = await fetch(
    `${BASE_URL}/center/${centerId}`
  );

  if (!res.ok) {
    throw new Error("Failed to fetch center detail");
  }

  return res.json();
}