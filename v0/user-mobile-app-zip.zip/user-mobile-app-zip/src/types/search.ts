export type CTAActionPayload = {
  center_id: string;
  modality_id: string;
  test_config_id: string;
};

export type Section = {
  type: string;
  value: any;
};

export type SearchCard = {
  id: string;
  sections: Section[];
};

export type SearchResponse = {
  cards: SearchCard[];
  meta: {
    total_results: number;
    returned: number;
    search_window_days: number;
    preferred_date: string;
  };
};

export type SearchRequest = {
  location: string | null;
  modality: string | null;
  test_keyword: string | null;
  preferred_date: string | null;
  search_window_days: number;
  sort: string | null;
  limit: number;
};