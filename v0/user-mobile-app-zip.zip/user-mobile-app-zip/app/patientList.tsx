import { router, useLocalSearchParams } from "expo-router";
import { useEffect, useState } from "react";
import { FlatList, Pressable, Text, View } from "react-native";
import { getPatients } from "../src/lib/patientApi";

export default function PatientScreen() {
  const params = useLocalSearchParams();
  console.log("Patient list Screen Params:", JSON.stringify(params, null, 2));

  const [patients, setPatients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log("global.userId: ",global.userId);
    if (!global.userId) {
      router.replace({
        pathname: "/login",
        params,
      });
      return;
    }

    loadPatients();
  }, []);

  const loadPatients = async () => {
    try {
      const res = await getPatients();

      // Debug response
      console.log("PATIENT API RESPONSE:", JSON.stringify(res, null, 2));

      // Support multiple response formats
      if (Array.isArray(res)) {
        setPatients(res);
      } else if (res?.patients) {
        setPatients(res.patients);
      } else if (res?.data) {
        setPatients(res.data);
      } else {
        setPatients([]);
      }
    } catch (err) {
      console.log("Patient fetch error:", err);
      setPatients([]);
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <View style={{ padding: 20 }}>
        <Text>Loading patients...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 22, fontWeight: "bold", marginBottom: 20 }}>
        Select Patient
      </Text>
      {/* <Text style={{ fontSize: 22, fontWeight: "bold", marginBottom: 20 }}>
        JSON.stringify(patients): {JSON.stringify(patients)}
      </Text> */}
      
      <FlatList
        data={patients}
        keyExtractor={(item, index) =>
          item?.id ? item.id.toString() : index.toString()
        }
        ListEmptyComponent={
          <Text style={{ marginTop: 20 }}>No patients found. Please add a patient.</Text>            
          // params.upi_id ? <Text style={{ marginTop: 20 }}>Please add a patient for this UPI ID: {params.upi_id} in your account.</Text> : <Text style={{ marginTop: 20 }}>No patients found. Please add a patient.</Text>            
        }
        renderItem={({ item }) => (
          <Pressable
            onPress={() =>
              router.push({
                pathname: "/review",
                params: { ...params, firstName: item.firstName, lastName: item.lastName, relation: item.relation, patientId: item.id, gender: item.gender, upiId: item.upiId },
              })
            }
            style={{
              padding: 14,
              borderBottomWidth: 1,
              borderColor: "#ddd",
            }}
          >
            <Text style={{ fontSize: 16 }}>{item.firstName}</Text>
            <Text style={{ fontSize: 16 }}>{item.gender}</Text>
            <Text style={{ fontSize: 16 }}>{item.relation}</Text>
          </Pressable>
        )}
      />

      <Pressable
        onPress={() =>
          router.push({
            pathname: "/patientUpi",
            params,
          })
        }
        style={{
          marginTop: 30,
          backgroundColor: "green",
          padding: 14,
          borderRadius: 6,
        }}
      >
        <Text style={{ color: "white", textAlign: "center", fontSize: 16 }}>
          Add Patient
        </Text>
      </Pressable>
    </View>
  );
}