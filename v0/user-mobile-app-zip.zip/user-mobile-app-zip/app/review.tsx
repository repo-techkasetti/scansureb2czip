import { router, useLocalSearchParams } from "expo-router";
import { Pressable, Text, View } from "react-native";
import RazorpayCheckout from "react-native-razorpay";
import useFetch from "../src/hooks/useFetch";
import { createBooking, verifyPayment } from "../src/lib/bookingApi";
import { fetchCenterDetail } from "../src/lib/centerApi";

export default function Review() {

  const params = useLocalSearchParams();
  console.log("Review page params 1:", JSON.stringify(params, null, 2));
  const { centerId, modalityId, testConfigId, date, slot, firstName, lastName, relation, gender, upiId, patientId } =
    useLocalSearchParams();
  const { data, loading } = useFetch(() =>
    fetchCenterDetail(centerId as string)
  );

  if (loading) return <Text>Loading...</Text>;
  if (!data) return <Text>No data</Text>;

  const center = data;

  const modality = center.modalities.find(
    (m: any) => m.id === modalityId
  );

  const test = modality?.tests.find(
    (t: any) => t.id === testConfigId
  );

  const openPatientScreen = () => {
    router.push({
      pathname: "/patientList",
      params: {
        centerId,
        modalityId,
        testConfigId,
        date,
        slot
      }
    });
  };

  const handleConfirmPay = async () => {

    try {

      const booking = await createBooking({
        centerId,
        modalityId,
        testConfigId,
        date,
        slot,
        patientId
      });

      // ✅ ADD THIS LOG (Check API response)
      console.log("Booking response:", booking);

      const options = {
        key: "rzp_test_SN18Mc01KDKfJx",
        amount: booking.amount * 100,
        currency: "INR",
        name: "Diagnostic Booking",
        description: "Scan Appointment",
        order_id: booking.orderId,
        theme: { color: "#3399cc" }
      };

      // ✅ ADD THIS LOG (Check Razorpay trigger)
      console.log("Opening Razorpay with options:", options);
      
      RazorpayCheckout.open(options)
        .then(async (payment: any) => {
          
          //
          console.log("Razorpay payment response<><>:", payment);
          //
          await verifyPayment({
            razorpay_order_id: payment.razorpay_order_id,
            razorpay_payment_id: payment.razorpay_payment_id,
            razorpay_signature: payment.razorpay_signature
          });

          
          router.push("/success");

        })
        .catch((error: any) => {
          console.log("Payment Failed", error);
        });

    } catch (err) {
      console.log("Booking error", err);
    }
  };

  return (
    <View style={{ padding: 20 }}>

      <Text style={{ fontSize: 22, fontWeight: "bold" }}>
        Review Booking
      </Text>

      <Text style={{ marginTop: 20, fontWeight: "bold" }}>
        Center
      </Text>

      <Text>{center.name}</Text>
      <Text>{center.address}</Text>

      <Text style={{ marginTop: 20, fontWeight: "bold" }}>
        Scan
      </Text>

      <Text>
        {modality?.name} – {test?.testKeyword}
      </Text>

      <Text style={{ marginTop: 20, fontWeight: "bold" }}>
        Appointment
      </Text>

      <Text>{date}</Text>
      <Text>{slot}</Text>

      <Text style={{ marginTop: 20, fontWeight: "bold" }}>
        Price
      </Text>

      <Text>₹{test?.price}</Text>

      <Text style={{ marginTop: 20, fontWeight: "bold" }}>
        Patient
      </Text>

      {!params.firstName ? (
        <Text style={{ marginTop: 10 }}>No patient selected</Text>
      ) : (
        <>
          <Text style={{ marginTop: 5 }}>
            Patient Name: {params.firstName} {params.lastName}
          </Text>
          <Text style={{ marginTop: 5 }}>
            Relation: {params.relation}
          </Text>
        </>
      )}

      <Pressable
        onPress={openPatientScreen}
        style={{
          marginTop: 10,
          backgroundColor: "#ddd",
          padding: 10
        }}
      >
        <Text>
          {firstName ? "Change Patient" : "Select Patient"}
        </Text>
      </Pressable>

      <Pressable
        onPress={handleConfirmPay}
        disabled={!firstName}
        style={{
          marginTop: 30,
          backgroundColor: firstName ? "green" : "gray",
          padding: 14
        }}
      >
        <Text style={{ color: "white", textAlign: "center" }}>
          Confirm & Pay
        </Text>
      </Pressable>
      <Pressable
        onPress={() => router.push("/")}
        disabled={!firstName}
        style={{
          marginTop: 30,
          backgroundColor: firstName ? "blue" : "gray",
          padding: 14
        }}
      >
        <Text style={{ color: "white", textAlign: "center" }}>
          Go to Home
        </Text>
      </Pressable>

    </View>
  );
}