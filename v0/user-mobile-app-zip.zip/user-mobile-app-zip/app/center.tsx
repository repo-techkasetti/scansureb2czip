import { router, useLocalSearchParams } from "expo-router";
import { useState } from "react";
import { ScrollView, Text, TouchableOpacity } from "react-native";
import useFetch from "../src/hooks/useFetch";
import { fetchCenterDetail } from "../src/lib/centerApi";

export default function Center() {
  const params = useLocalSearchParams();

  const centerId = params.centerId as string;
  const modalityId = params.modalityId as string;
  const testConfigId = params.testConfigId as string;

  console.log("CENTER PARAMS:", params);

  const { data, loading, error } = useFetch(() => {
    if (!centerId) return Promise.resolve(null);
    return fetchCenterDetail(centerId);
  });

  const [selectedModality, setSelectedModality] = useState(modalityId);
  const [selectedTest, setSelectedTest] = useState(testConfigId);

  if (loading) return <Text>Loading center...</Text>;
  if (error) return <Text>Error loading center</Text>;
  if (!data) return <Text>No data</Text>;

  const center = data;

  const selectedModalityObj = center.modalities.find(
    (m: any) => m.id === selectedModality
  );

  const selectedTestObj = selectedModalityObj?.tests.find(
    (t: any) => t.id === selectedTest
  );

  return (
    <ScrollView style={{ flex: 1, padding: 20 }}>
      
      {/* Center Info */}
      <Text style={{ fontSize: 22, fontWeight: "bold" }}>
        {center.name}
      </Text>

      <Text>{center.address}</Text>
      <Text>⭐ {center.rating}</Text>

      {/* Service Chips */}
      <Text style={{ marginTop: 20, fontWeight: "bold" }}>
        Service
      </Text>

      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {center.modalities.map((modality: any) => (
          <TouchableOpacity
            key={modality.id}
            onPress={() => {
              setSelectedModality(modality.id);
              setSelectedTest(modality.tests[0]?.id);
            }}
            style={{
              padding: 10,
              borderWidth: 1,
              borderRadius: 20,
              marginRight: 10,
              backgroundColor:
                selectedModality === modality.id ? "#007AFF" : "white",
            }}
          >
            <Text
              style={{
                color:
                  selectedModality === modality.id
                    ? "white"
                    : "black",
              }}
            >
              {modality.code}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Body Part Chips */}
      <Text style={{ marginTop: 20, fontWeight: "bold" }}>
        Body Part
      </Text>

      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {selectedModalityObj?.tests.map((test: any) => (
          <TouchableOpacity
            key={test.id}
            onPress={() => setSelectedTest(test.id)}
            style={{
              padding: 10,
              borderWidth: 1,
              borderRadius: 20,
              marginRight: 10,
              backgroundColor:
                selectedTest === test.id ? "#007AFF" : "white",
            }}
          >
            <Text
              style={{
                color:
                  selectedTest === test.id ? "white" : "black",
              }}
            >
              {test.testKeyword}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Price */}
      {selectedTestObj && (
        <Text style={{ marginTop: 20, fontSize: 18 }}>
          Price: ₹{selectedTestObj.price}
        </Text>
      )}

      {/* Book */}
      <TouchableOpacity
        onPress={() =>
          router.push({
            pathname: "/calendar",
            // pathname: "/availability",
            params: {
              centerId,
              modalityId: selectedModality,
              testConfigId: selectedTest,
            },
          })
        }
        style={{
          marginTop: 30,
          backgroundColor: "#007AFF",
          padding: 15,
          borderRadius: 10,
          alignItems: "center",
        }}
      >
        <Text style={{ color: "white", fontWeight: "bold" }}>
          Confirm & Book
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}