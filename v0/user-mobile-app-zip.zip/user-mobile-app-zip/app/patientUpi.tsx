
import { router, useLocalSearchParams } from "expo-router";
import { useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { createPatient, getPatientByUpi } from "../src/lib/patientApi";

export default function AadhaarScreen() {

  const params = useLocalSearchParams();

  const [aadhaar, setAadhaar] = useState("");

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [gender, setGender] = useState("");
  const [dob, setDob] = useState("");
  const [relation, setRelation] = useState("");
  const [upi, setUpi] = useState("");

  const [loading, setLoading] = useState(false);

  const [step, setStep] = useState<"aadhaar" | "register">("aadhaar");

  const handleCheck = async () => {
    if (loading) return;        // 🚫 prevent double click
    setLoading(true);           // ⏳ start loading
    console.log("handleCheck--i/p: ", aadhaar);
    console.log("handleCheck-upi: ", upi);
    
    const res = await fetch(
      `http://${process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS_LH}:3000/api/patient/aadhaar/${aadhaar}`
      // `http://${process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS_LH}:3001/api/patient/aadhaar/${aadhaar}`
      // `http://localhost:3001/api/patient/aadhaar/${aadhaar}`
    );

    const data = await res.json();
    console.log("handleCheck: ", JSON.stringify(data, null, 2));
    console.log("handleCheck-data.data: ", JSON.stringify(data.data, null, 2));
    // console.log("handleCheck page params:", JSON.stringify(params, null, 2));

    if (data.status === "found") {
      setUpi(data.data.upi_id);
    //
    console.log("HC-Patient found with UPI:", data.data.upi_id);
    try{
      const patient = await getPatientByUpi(data.data.upi_id);
      console.log('getPatientByUpi in patientUpi: ',JSON.stringify(patient, null, 2));
      if (patient.status === "found") {
        const p = patient.data;
        setFirstName(p.firstName);
        setLastName(p.lastName);
        setPhone(p.phone);
        setDob(p.dob);
        setGender(p.gender);
        setRelation(p.relation);
        router.replace({ 
          pathname: "/review",
          params: {
            ...params,
            upi_id: data.data.upi_id,
            firstName: p.firstName,
            lastName: p.lastName,
            phone: p.phone,
            dob: p.dob,
            gender: p.gender,
            relation: p.relation,
            patientId: p.id
          }
        });
        //
        return;
        //
      }else{
        console.log("Patient not found in local DB, navigating to register");
        const p = data.data;
        
        setFirstName(p.firstName || "");
        setLastName(p.lastName || "");
        setPhone(p.phone || "");
        setDob(p.dob || "");
        setGender(p.gender || "");
        setStep("register");
      }
    } catch(e){
      console.error("Error fetching patient by UPI:", e);
    }  

    } else {
      console.log("handleCheck-upi-else: ", upi);
      setStep("register");

    }
    setLoading(false);          // ✅ stop loading
  };

  const handleRegister = async () => {
    if (loading) return;        // 🚫 prevent double click
    setLoading(true);           // ⏳ start loading
    console.log("handleRegister-upi: ", upi);
    //---
    let finalUpi = upi;
    //
    let newPatient = null;
    //
    // ==========================
    // STEP 1: GET / CREATE UPI
    // ==========================
    if (!finalUpi) {
      console.log("No UPI, registering patient...");
    
      const res = await fetch(
        // `http://localhost:3001/api/patient/register`,
        // `http://${process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS_LH}:3001/api/patient/register`,
        `http://${process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS_LH}:3000/api/patient/register`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            aadhaar_no: aadhaar,
            firstName,
            lastName,
            phone,
            dob,
            gender
          })
        }
      );
      //
      if (!res.ok) {
        console.error("Register API failed:", res.status);
        return;
      }
      //
      const data = await res.json();
      console.log("REGISTER RESPONSE:", data);
    
      // ✅ CREATED
      if (data.status === "created") {
        finalUpi = data.data.upi_id;
      }
    
      // ✅ ALREADY EXISTS
      else if (data.message === "Patient already exists") {
        console.log("Fetching existing patient UPI...");
    
        const res2 = await fetch(
          // `http://localhost:3001/api/patient/aadhaar/${aadhaar}`
          `http://${process.env.EXPO_PUBLIC_LOCAL_IP_ADDRESS_LH}:3001/api/patient/aadhaar/${aadhaar}`
        );
        const data2 = await res2.json();
    
        finalUpi = data2?.data?.upi_id;
      }
    
      else {
        console.error("Register failed:", data);
        return;
      }
    
      if (!finalUpi) {
        console.error("UPI missing after register");
        return;
      }
    
      // optional UI state update
      setUpi(finalUpi);
    }
    
    // ==========================
    // STEP 2: SAVE LOCAL DB
    // ==========================
    try {
      //
      newPatient = 
      await createPatient({
        firstName,
        lastName,
        phone,
        upi_id: finalUpi,
        dob,
        gender,
        relation
      });
      console.log('newPatient in  inside: ',JSON.stringify(newPatient, null, 2));
      //
      // await createPatient({
      //   firstName,
      //   lastName,
      //   phone,
      //   upi_id: finalUpi,
      //   dob,
      //   gender,
      //   relation
      // });
    
      console.log("Patient saved in local DB");
    } catch (e) {
      console.error("Local DB error:", e);
      return; // ❗ stop if DB fails
    }
    //
    console.log('newPatient in  outside:=> ',JSON.stringify(newPatient, null, 2));
    //
    // ==========================
    // STEP 3: NAVIGATE
    // ==========================
    router.replace({
      pathname: "/review",
      params: {
        ...params,
        upi_id: finalUpi, // ✅ FIXED
        firstName,
        lastName,
        phone,
        dob,
        gender,
        relation,
        patientId: newPatient.id // ✅ from DB response
      },
    });
    //---
    setLoading(false);           // ⏹ stop loading
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>

      <Text style={{ fontSize: 22, fontWeight: "bold" }}>
        Universal Patient Identification
      </Text>

      {step === "aadhaar" && (
        <>
          <TextInput
            maxLength={12}
            keyboardType="numeric"
            placeholder="Enter Aadhaar"
            value={aadhaar}
            onChangeText={setAadhaar}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 20
            }}
          />

          <Pressable
            onPress={handleCheck}
            disabled={loading}
            style={{
              marginTop: 20,
              backgroundColor: loading ? "gray" : "blue",
              padding: 12
            }}
          >
            <Text style={{ color: "white", textAlign: "center" }}>
              Check Patient
            </Text>
          </Pressable>
        </>
      )}

      {step === "register" && (
        <>
          <Text style={{ marginTop: 20 }}>
            Patient not found. Register.
          </Text>

          <TextInput
            placeholder="First Name"
            value={firstName}
            onChangeText={setFirstName}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 10
            }}
          />
          <TextInput
            placeholder="Last Name"
            value={lastName}
            onChangeText={setLastName}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 10
            }}
          />

          <TextInput
            placeholder="Phone"
            value={phone}
            onChangeText={setPhone}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 10
            }}
          />
          <TextInput
            placeholder="Date of Birth"
            value={dob}
            onChangeText={setDob}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 10
            }}
          />
          <TextInput
            placeholder="Gender"
            value={gender}
            onChangeText={setGender}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 10
            }}
          />
          <TextInput
            placeholder="Relation (SELF / FATHER / MOTHER)"
            value={relation}
            onChangeText={setRelation}
            style={{
              borderWidth: 1,
              padding: 10,
              marginTop: 20
            }}
          />

          <Pressable
            onPress={handleRegister}
            disabled={loading}
            style={{
              marginTop: 20,
              backgroundColor: loading ? "gray" : "green",
              padding: 12
            }}
          >
            <Text style={{ color: "white", textAlign: "center" }}>
              Register Patient
            </Text>
          </Pressable>
        </>
      )}

    </View>
  );
}