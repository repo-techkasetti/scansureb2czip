import express, { Request, Response } from "express";
import axios from "axios";
import { connectKafka, isKafkaConnected, producer } from "./kafka";
import { AppointmentApiResponse, WebhookRequest } from "./types";

const app = express();
app.use(express.json());

const PORT = 4000;
const KAFKA_TOPIC = "b2c.radiology.orders";

async function ensureKafkaConnection(): Promise<void> {
  try {
    await connectKafka();
  } catch (error) {
    console.error("Kafka unavailable, retrying in 10 seconds:", error);
    setTimeout(() => {
      void ensureKafkaConnection();
    }, 10_000);
  }
}

app.post("/webhook/event", async (req: Request, res: Response) => {
  try {
    const { appointment_id, appointment_Id } = req.body as WebhookRequest;
    const resolvedAppointmentId = appointment_id ?? appointment_Id;

    if (!resolvedAppointmentId) {
      return res
        .status(400)
        .json({ error: "appointment_id is required" });
    }

    if (!isKafkaConnected()) {
      return res.status(503).json({
        error: "Kafka unavailable",
        message: "Producer is not connected. Please retry shortly.",
      });
    }

    console.log("Received appointment_id:", resolvedAppointmentId);

    const response = await axios.get<AppointmentApiResponse>(
      `http://localhost:3000/api/appointments/${resolvedAppointmentId}`
    );
    const appointmentPayload = response.data;

    await producer.send({
      topic: KAFKA_TOPIC,
      messages: [{ value: JSON.stringify(appointmentPayload) }],
    });

    const payload = { topic: KAFKA_TOPIC, message: appointmentPayload };
    console.log("Sent to Kafka:", payload);
    return res.json({ message: "Success", payload });
  } catch (error: unknown) {
    if (axios.isAxiosError(error)) {
      console.error("Error:", error.message);
    } else {
      console.error("Error:", error);
    }
    return res.status(500).json({ error: "Internal server error" });
  }
});

async function start(): Promise<void> {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  void ensureKafkaConnection();
}

start().catch((error) => {
  console.error("Failed to start service:", error);
  process.exit(1);
});
