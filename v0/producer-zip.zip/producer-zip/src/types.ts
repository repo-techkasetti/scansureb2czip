export interface WebhookRequest {
  appointment_id: string;
  appointment_Id?: string;
}

export interface AppointmentApiResponse {
  tenant_id: string;
  payment_order_id: string;
  unification_id: string;
  patient_id: string;
  patient_name: string;
  gender: string;
  birthdate: string;
  modality: string;
  study_description: string;
  care_setting: string;
  timestamp: string;
}
