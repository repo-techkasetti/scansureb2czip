import { Kafka } from "kafkajs";

const kafka = new Kafka({
  clientId: "webhook-service",
  brokers: ["172.16.16.39:9092"],
  // brokers: ["192.168.1.43:9092"],
  // brokers: ["localhost:9092"],
});

export const producer = kafka.producer();
let kafkaConnected = false;

export async function connectKafka(): Promise<void> {
  await producer.connect();
  kafkaConnected = true;
  console.log("Kafka connected");
}

export function isKafkaConnected(): boolean {
  return kafkaConnected;
}
