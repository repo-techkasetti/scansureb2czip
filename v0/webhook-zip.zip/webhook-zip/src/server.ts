import { createHmac, timingSafeEqual } from "node:crypto";
import { createServer, IncomingMessage, ServerResponse } from "node:http";

const PORT = Number(process.env.PORT ?? 3001);
const WEBHOOK_PATH = process.env.WEBHOOK_PATH ?? "/razorpay-webhook";
const WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET;
const PAYMENT_API_BASE_URL = process.env.PAYMENT_API_BASE_URL ?? "http://localhost:3000/api/payment";
const EVENT_API_URL = process.env.EVENT_API_URL ?? "http://localhost:4000/webhook/event";
const PAYMENT_LOOKUP_RETRY_COUNT = Number(process.env.PAYMENT_LOOKUP_RETRY_COUNT ?? 5);
const PAYMENT_LOOKUP_RETRY_DELAY_MS = Number(process.env.PAYMENT_LOOKUP_RETRY_DELAY_MS ?? 2000);

type RazorpayPayload = {
  event?: string;
  payload?: {
    payment?: {
      entity?: {
        id?: string;
        amount?: number;
        currency?: string;
        status?: string;
        email?: string;
        contact?: string;
        order_id?: string;
        method?: string;
      };
    };
  };
};

type PaymentLookupResult = {
  appointment_id?: string;
  status?: string;
};

function readRawBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    let data = "";

    req.setEncoding("utf8");
    req.on("data", (chunk: string) => {
      data += chunk;
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

function sendJson(res: ServerResponse, statusCode: number, body: Record<string, unknown>): void {
  res.writeHead(statusCode, { "content-type": "application/json" });
  res.end(JSON.stringify(body));
}

function verifyRazorpaySignature(rawBody: string, signature: string): boolean {
  if (!WEBHOOK_SECRET) {
    return true;
  }

  const expected = createHmac("sha256", WEBHOOK_SECRET).update(rawBody).digest("hex");
  const signatureBuffer = Buffer.from(signature, "utf8");
  const expectedBuffer = Buffer.from(expected, "utf8");

  if (signatureBuffer.length !== expectedBuffer.length) {
    return false;
  }

  return timingSafeEqual(signatureBuffer, expectedBuffer);
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function extractSummary(body: unknown): Record<string, string | number> | null {
  if (!isObject(body)) {
    return null;
  }

  const typedBody = body as RazorpayPayload;
  const payment = typedBody.payload?.payment?.entity;

  const summaryEntries: Array<[string, string | number | undefined]> = [
    ["event", typedBody.event],
    ["paymentId", payment?.id],
    ["orderId", payment?.order_id],
    ["amount", payment?.amount],
    ["currency", payment?.currency],
    ["status", payment?.status],
    ["method", payment?.method],
    ["email", payment?.email],
    ["contact", payment?.contact]
  ];

  const filteredEntries = summaryEntries.filter((entry): entry is [string, string | number] => entry[1] !== undefined);

  if (filteredEntries.length === 0) {
    return null;
  }

  return Object.fromEntries(filteredEntries);
}

function getPaymentId(body: unknown): string | null {
  if (!isObject(body)) {
    return null;
  }

  const typedBody = body as RazorpayPayload;
  return typedBody.payload?.payment?.entity?.id ?? null;
}

async function fetchPaymentResult(paymentId: string): Promise<{ status: number; body: string }> {
  const response = await fetch(`${PAYMENT_API_BASE_URL}/${paymentId}`, {
    method: "GET",
    headers: {
      accept: "application/json"
    }
  });

  const body = await response.text();

  return {
    status: response.status,
    body
  };
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

async function fetchPaymentResultWithRetry(paymentId: string): Promise<{ status: number; body: string; attempt: number }> {
  for (let attempt = 1; attempt <= PAYMENT_LOOKUP_RETRY_COUNT; attempt += 1) {
    const result = await fetchPaymentResult(paymentId);

    if (result.status !== 404 || attempt === PAYMENT_LOOKUP_RETRY_COUNT) {
      return {
        ...result,
        attempt
      };
    }

    console.log(
      `Payment API returned 404 for ${paymentId}. Retrying in ${PAYMENT_LOOKUP_RETRY_DELAY_MS}ms ` +
      `(attempt ${attempt}/${PAYMENT_LOOKUP_RETRY_COUNT})...`
    );

    await sleep(PAYMENT_LOOKUP_RETRY_DELAY_MS);
  }

  return {
    status: 404,
    body: "{\"message\":\"Payment not found\"}",
    attempt: PAYMENT_LOOKUP_RETRY_COUNT
  };
}

function getAppointmentId(body: string): string | null {
  try {
    const parsedBody = JSON.parse(body) as PaymentLookupResult;
    return parsedBody.appointment_id ?? null;
  } catch {
    return null;
  }
}

async function postWebhookEvent(appointmentId: string): Promise<{ status: number; body: string }> {
  const response = await fetch(EVENT_API_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      accept: "application/json"
    },
    body: JSON.stringify({
      appointment_id: appointmentId
    })
  });

  const body = await response.text();

  return {
    status: response.status,
    body
  };
}

async function handleWebhook(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const rawBody = await readRawBody(req);
  const signature = req.headers["x-razorpay-signature"];
  const eventId = req.headers["x-razorpay-event-id"] ?? "unknown";

  if (WEBHOOK_SECRET && typeof signature !== "string") {
    sendJson(res, 400, {
      ok: false,
      message: "Missing x-razorpay-signature header"
    });
    return;
  }

  if (WEBHOOK_SECRET && (typeof signature !== "string" || !verifyRazorpaySignature(rawBody, signature))) {
    console.error("\nSignature verification failed.");
    console.error(`Event ID: ${String(eventId)}`);
    console.error(`Received at: ${new Date().toISOString()}\n`);

    sendJson(res, 401, {
      ok: false,
      message: "Invalid Razorpay signature"
    });
    return;
  }

  let parsedBody: unknown = rawBody;

  try {
    parsedBody = rawBody ? JSON.parse(rawBody) : {};
  } catch {
    // Keep raw text if Razorpay sends malformed JSON or a plain payload.
  }

  const summary = extractSummary(parsedBody);
  const paymentId = getPaymentId(parsedBody);

  console.log("\n=== Razorpay webhook received ===");
  console.log(`Time: ${new Date().toISOString()}`);
  console.log(`Method: ${req.method}`);
  console.log(`Path: ${req.url}`);
  console.log(`Event ID: ${String(eventId)}`);
  console.log(`Signature present: ${typeof signature === "string" && signature.length > 0 ? "yes" : "no"}`);
  console.log(`Signature verified: ${WEBHOOK_SECRET ? "yes" : "disabled"}`);

  if (summary) {
    console.log("Summary:");
    console.log(JSON.stringify(summary, null, 2));
  }

  if (paymentId) {
    try {
      const paymentResult = await fetchPaymentResultWithRetry(paymentId);

      console.log(`Payment API URL: ${PAYMENT_API_BASE_URL}/${paymentId}`);
      console.log(`Payment API Attempt: ${paymentResult.attempt}/${PAYMENT_LOOKUP_RETRY_COUNT}`);
      console.log(`Payment API Status: ${paymentResult.status}`);
      console.log("Payment API Response:");
      console.log(paymentResult.body);

      const appointmentId = paymentResult.status >= 200 && paymentResult.status < 300
        ? getAppointmentId(paymentResult.body)
        : null;

      if (appointmentId) {
        const eventResult = await postWebhookEvent(appointmentId);

        console.log(`Event API URL: ${EVENT_API_URL}`);
        console.log(`Event API Status: ${eventResult.status}`);
        console.log("Event API Response:");
        console.log(eventResult.body);
      } else {
        console.log("Event API call skipped: no appointment_id found in payment API response.");
      }
    } catch (error) {
      console.error(`Webhook follow-up failed for payment ${paymentId}:`, error);
    }
  } else {
    console.log("Payment API call skipped: no payment id found in webhook payload.");
  }

  console.log("=================================\n");

  sendJson(res, 200, {
    ok: true,
    message: "Webhook received"
  });
}

const server = createServer(async (req, res) => {
  try {
    if (req.method === "GET" && req.url === "/") {
      sendJson(res, 200, {
        ok: true,
        message: "Razorpay webhook server is running",
        webhookPath: WEBHOOK_PATH
      });
      return;
    }

    if (req.method === "POST" && req.url === WEBHOOK_PATH) {
      await handleWebhook(req, res);
      return;
    }

    sendJson(res, 404, {
      ok: false,
      message: "Not found"
    });
  } catch (error) {
    console.error("Webhook handler error:", error);
    sendJson(res, 500, {
      ok: false,
      message: "Internal server error"
    });
  }
});

server.on("error", (error) => {
  if ("code" in error && error.code === "EADDRINUSE") {
    console.error(`Port ${PORT} is already in use. Set a different PORT and try again.`);
    console.error(`Example: $env:PORT="3001"; npm.cmd run dev`);
    process.exit(1);
  }

  console.error("Server startup error:", error);
  process.exit(1);
});

server.listen(PORT, () => {
  console.log(`Webhook server listening on http://localhost:${PORT}`);
  console.log(`POST Razorpay webhooks to http://localhost:${PORT}${WEBHOOK_PATH}`);
  console.log(`Payment API base URL: ${PAYMENT_API_BASE_URL}`);
  console.log(`Payment API retries: ${PAYMENT_LOOKUP_RETRY_COUNT} every ${PAYMENT_LOOKUP_RETRY_DELAY_MS}ms`);
  console.log(`Event API URL: ${EVENT_API_URL}`);

  if (WEBHOOK_SECRET) {
    console.log("Signature verification: enabled");
  } else {
    console.log("Signature verification: disabled (set RAZORPAY_WEBHOOK_SECRET to enable)");
  }
});
