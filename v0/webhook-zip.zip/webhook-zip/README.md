# Razorpay webhook listener

Simple Node + TypeScript server that prints incoming Razorpay webhook headers and payloads to the terminal.

## Run

```powershell
$env:PORT="3001"
$env:WEBHOOK_PATH="/razorpay-webhook"
$env:RAZORPAY_WEBHOOK_SECRET="your_webhook_secret"
npm.cmd run dev
```

If you do not want to verify signatures yet, skip `RAZORPAY_WEBHOOK_SECRET`.

## Test with Postman

Send a `POST` request to:

```text
http://localhost:3001/razorpay-webhook
```

Use header:

```text
Content-Type: application/json
```

Optional header:

```text
x-razorpay-signature: test-signature
```

Example JSON body:

```json
{
  "event": "payment.captured",
  "payload": {
    "payment": {
      "entity": {
        "id": "pay_test_123",
        "order_id": "order_test_123",
        "amount": 50000,
        "currency": "INR",
        "status": "captured",
        "method": "upi",
        "email": "test@example.com",
        "contact": "9999999999"
      }
    }
  }
}
```

## Razorpay webhook URL

Use:

```text
http://your-public-url/razorpay-webhook
```

For local development, expose your server with a tunnel such as ngrok or Cloudflare Tunnel, then paste that public URL into Razorpay's webhook settings.

## Enable real Razorpay signature verification

In PowerShell:

```powershell
$env:PORT="3001"
$env:RAZORPAY_WEBHOOK_SECRET="your_real_razorpay_webhook_secret"
npm.cmd run dev
```

Once that secret is set, the server will reject webhook requests whose `x-razorpay-signature` does not match Razorpay's HMAC signature.

## What you will see

Whenever Razorpay sends a webhook, the terminal prints:

- important payment summary fields first
- request time
- HTTP headers
- parsed JSON body
- event id


==================
crs-backend
--
PS C:\Users\DeB\Desktop\crs-backend-service> 
-
npm.cmd run dev
--
webhook
--
PS C:\Users\DeB\Desktop\webhook> 
-
$env:PORT="3001"
-
PS C:\Users\DeB\Desktop\webhook> 
-
npm.cmd run dev
-
cloudflared tunnel --url http://localhost:3001
-
set in razorpay webhook
--
producer
--
PS C:\Users\DeB\Desktop\Producer> 
-
npm.cmd run dev
--
consumer:
--
PS C:\Users\DeB\Desktop\consumer> 
-
docker compose logs -f radiology-consumer
--
==================