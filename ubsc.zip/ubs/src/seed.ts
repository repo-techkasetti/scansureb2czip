import { prisma } from "./lib/prisma.js"
import { AppointmentStatus } from "../generated/prisma/client.js"



async function main() {
  console.log("🌱 Seeding started...")

  // 1️⃣ Create Vendor
  const vendor = await prisma.vendor.create({
    data: {
      name: "HealthCorp Pvt Ltd"
    }
  })

  // 2️⃣ Create Center
  const center = await prisma.center.create({
    data: {
      vendorId: vendor.id,
      name: "ABC Diagnostic Center",
      address: "Connaught Place, Delhi",
      latitude: 28.6304,
      longitude: 77.2177,
      timezone: "Asia/Kolkata"
    }
  })

  // 3️⃣ Create Modality
  const modality = await prisma.modality.create({
    data: {
      code: "MRI",
      name: "MRI Scan"
    }
  })

  // 4️⃣ Link Center ↔ Modality
  await prisma.centerModality.create({
    data: {
      centerId: center.id,
      modalityId: modality.id
    }
  })

  // 5️⃣ Create Machine
  const machine = await prisma.machine.create({
    data: {
      centerId: center.id,
      modalityId: modality.id,
      name: "MRI Machine 1"
    }
  })

  // 6️⃣ Create Operator
  const operator = await prisma.operator.create({
    data: {
      centerId: center.id,
      modalityId: modality.id,
      name: "Dr. Sharma"
    }
  })

  // 7️⃣ Create AvailabilityRule (for today)
  const today = new Date()
  const dayOfWeek = today.getDay() // 0 = Sunday, 6 = Saturday

  await prisma.availabilityRule.create({
    data: {
      machineId: machine.id,
      dayOfWeek,
      startTime: "10:00",
      endTime: "16:00",
      slotMinutes: 30
    }
  })

  // 8️⃣ Create Test Config
  const testConfig = await prisma.modalityTestConfig.create({
    data: {
      modalityId: modality.id,
      testKeyword: "BRAIN",
      durationMinutes: 30,
      price: 2500
    }
  })

  console.log("✅ Seeding completed successfully!")
  console.log("Center ID:", center.id)
  console.log("Modality ID:", modality.id)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })