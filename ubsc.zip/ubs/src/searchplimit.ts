import { prisma } from "./lib/prisma.js";
import { getAvailabilitySummary } from "../src/avlsummary.js";
import pLimit from "p-limit";

type SortOption = {
  by: "PRICE" | "RATING" | "DISTANCE" | "EARLIEST_AVAILABLE";
  order: "ASC" | "DESC";
};

type SearchPayload = {
  location?: { lat: number; lng: number; radius_km?: number } | null;
  modality?: string | null;
  test_keyword?: string | null;
  preferred_date?: string | null;
  search_window_days?: number;
  sort?: SortOption[];
  limit?: number;
};

function buildDateRange(preferredDate: string, windowDays: number) {
  const start = new Date(preferredDate);
  const end = new Date(preferredDate);
  end.setDate(end.getDate() + windowDays - 1);

  return {
    startDate: start.toISOString(),
    endDate: end.toISOString(),
  };
}

async function searchService(rawPayload: SearchPayload) {
  const today = new Date().toISOString().split("T")[0];

  const preferred_date = rawPayload.preferred_date ?? today;
  const search_window_days = rawPayload.search_window_days ?? 3;
  const sort =
    rawPayload.sort && rawPayload.sort.length > 0
      ? rawPayload.sort
      : [{ by: "DISTANCE", order: "ASC" }];
  const limitCount = rawPayload.limit ?? 20;

  const { startDate, endDate } = buildDateRange(
    preferred_date,
    search_window_days
  );

  const centers = await prisma.center.findMany({
    where: {
      isActive: true,
      isDeleted: false,
    },
    include: {
      modalities: {
        where: { isActive: true },
        include: {
          modality: {
            include: {
              testConfigs: {
                where: { isDeleted: false },
              },
            },
          },
        },
      },
    },
  });

  // ===============================
  // ✅ CONTROLLED CONCURRENCY SETUP
  // ===============================

  const CONCURRENCY_LIMIT = 20; // adjust based on DB capacity
  const limiter = pLimit(CONCURRENCY_LIMIT);

  const tasks: Promise<any>[] = [];

  for (const center of centers) {
    for (const cm of center.modalities) {
      const modality = cm.modality;

      if (rawPayload.modality && modality.code !== rawPayload.modality)
        continue;

      for (const test of modality.testConfigs) {
        if (
          rawPayload.test_keyword &&
          !test.testKeyword
            .toLowerCase()
            .includes(rawPayload.test_keyword.toLowerCase())
        )
          continue;

        tasks.push(
          limiter(async () => {
            const availability = await getAvailabilitySummary({
              centerId: center.id,
              modalityId: modality.id,
              testKeyword: test.testKeyword,
              startDate,
              endDate,
            });

            if (availability.totalAvailableSlots === 0) return null;

            return {
              center,
              modality,
              test,
              availability,
            };
          })
        );
      }
    }
  }

  const rawResults = await Promise.all(tasks);
  const results = rawResults.filter(Boolean);

  // ===============================
  // ✅ SORTING
  // ===============================

  const { by, order } = sort[0];

  results.sort((a, b) => {
    let valA = 0;
    let valB = 0;

    if (by === "PRICE") {
      valA = a.test.price;
      valB = b.test.price;
    }

    if (by === "RATING") {
      valA = a.center.rating ?? 0;
      valB = b.center.rating ?? 0;
    }

    if (by === "EARLIEST_AVAILABLE") {
      valA = new Date(a.availability.firstAvailableDate || 0).getTime();
      valB = new Date(b.availability.firstAvailableDate || 0).getTime();
    }

    return order === "ASC" ? valA - valB : valB - valA;
  });

  const limited = results.slice(0, limitCount);

  const cards = limited.map((item) => ({
    id: `${item.center.id}|${item.modality.id}|${item.test.id}`,
    sections: [
      { type: "TITLE", value: { text: item.center.name } },
      {
        type: "SUBTITLE",
        value: {
          text: `${item.modality.code} ${item.test.testKeyword}`,
        },
      },
      { type: "META", value: { text: item.center.address } },
      {
        type: "METRICS",
        value: {
          items: [{ label: "Rating", value: item.center.rating }],
        },
      },
      {
        type: "PRICE",
        value: {
          display: `Starting at ₹${item.test.price}`,
          min_price: item.test.price,
          currency: "INR",
        },
      },
      {
        type: "AVAILABILITY",
        value: item.availability,
      },
      {
        type: "CTA",
        value: {
          actions: [
            {
              label: "Book",
              action: "BOOK",
              payload: {
                center_id: item.center.id,
                modality_id: item.modality.id,
                test_config_id: item.test.id,
              },
            },
          ],
        },
      },
    ],
  }));

  return {
    cards,
    meta: {
      total_results: results.length,
      returned: cards.length,
      concurrency_limit: CONCURRENCY_LIMIT,
      search_window_days,
      preferred_date,
    },
  };
}

// Test
(async () => {
  const response = await searchService({
    test_keyword: "spine",
    sort: [{ by: "PRICE", order: "ASC" }],
    preferred_date: "2026-03-02",
    // limit: 1,
  });
  console.log(JSON.stringify(response, null, 2));
})();