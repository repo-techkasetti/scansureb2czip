// search.ts

import { prisma } from "./lib/prisma.js"
import { getAvailabilitySummary } from "../src/avlsummary.js"


// async function searchService(payload: {
//   modality?: string | null;
//   test_keyword?: string | null;
//   sort?: { by: "PRICE" | "RATING"; order: "ASC" | "DESC" }[];
//   limit?: number;
// }) {
//
type SortOption = {
  by: "PRICE" | "RATING" | "DISTANCE" | "EARLIEST_AVAILABLE";
  order: "ASC" | "DESC";
};

type SearchPayload = {
  location?: { lat: number; lng: number; radius_km?: number } | null;
  modality?: string | null;
  test_keyword?: string | null;
  preferred_date?: string | null;
  search_window_days?: number;
  sort?: SortOption[];
  limit?: number;
};

async function searchService(payload: SearchPayload) {

//

  const centers = await prisma.center.findMany({
    where: {
      isActive: true,
      isDeleted: false,

      // 🔥 Filter via relations properly
      modalities: {
        some: {
          isActive: true,
          modality: {
            isActive: true,
            ...(payload.modality && {
              code: payload.modality,
            }),
            testConfigs: {
              some: {
                isDeleted: false,
                ...(payload.test_keyword && {
                  testKeyword: {
                    contains: payload.test_keyword.toUpperCase(),
                    mode: "insensitive",
                  },
                }),
              },
            },
          },
        },
      },
    },

    include: {
      modalities: {
        where: { isActive: true },
        include: {
          modality: {
            include: {
              testConfigs: {
                where: { isDeleted: false },
              },
            },
          },
        },
      },
    },
  });

  let results: any[] = [];

  for (const center of centers) {
    for (const cm of center.modalities) {
      const modality = cm.modality;

      // Filter modality manually (safe way)
      if (payload.modality && modality.code !== payload.modality)
        continue;

      // for (const test of modality.testConfigs) {

      //   if (
      //     payload.test_keyword &&
      //     !test.testKeyword
      //       .toLowerCase()
      //       .includes(payload.test_keyword.toLowerCase())
      //   ) continue;

      //   results.push({ center, modality, test });
      // }
      //
      for (const test of modality.testConfigs) {

        if (
          payload.test_keyword &&
          !test.testKeyword
            .toLowerCase()
            .includes(payload.test_keyword.toLowerCase())
        ) continue;
      
        // ✅ Call availability service
        const availability = await getAvailabilitySummary({
          centerId: center.id,
          modalityId: modality.id,
          testKeyword: test.testKeyword,
          date: new Date().toISOString().split("T")[0], // today
        });
      
        results.push({
          center,
          modality,
          test,
          availability,
        });
      }
      //
    }
  }

  // Sorting
  if (payload.sort?.length) {
    const { by, order } = payload.sort[0];

    results.sort((a, b) => {
      if (by === "PRICE") {
        return order === "ASC"
          ? a.test.price - b.test.price
          : b.test.price - a.test.price;
      }

      if (by === "RATING") {
        return order === "ASC"
          ? a.center.rating - b.center.rating
          : b.center.rating - a.center.rating;
      }

      return 0;
    });
  }

  const limited = results.slice(0, payload.limit || 20);

  const cards = limited.map((item) => ({
    id: `${item.center.id}|${item.modality.id}|${item.test.id}`,
    sections: [
      {
        type: "TITLE",
        value: { text: item.center.name },
      },
      {
        type: "SUBTITLE",
        value: {
          text: `${item.modality.code} ${item.test.testKeyword}`,
        },
      },
      {
        type: "META",
        value: { text: item.center.address },
      },
      {
        type: "METRICS",
        value: {
          items: [
            { label: "Rating", value: item.center.rating },
          ],
        },
      },
      {
        type: "PRICE",
        value: {
          display: `Starting at ₹${item.test.price}`,
          min_price: item.test.price,
          currency: "INR",
        },
      },
      // {
      //   type: "AVAILABILITY",
      //   value: {
      //     badge: "Available Today",
      //     earliest_time: "15:20",
      //   },
      // },
      //
      {
        type: "AVAILABILITY",
        value: item.availability
          ? {
              totalAvailableSlots: item.availability.totalAvailableSlots,
              firstAvailableDate: item.availability.firstAvailableDate,
              earliestAvailableTime: item.availability.earliestAvailableTime,
            }
          : {
              totalAvailableSlots: 0,
              firstAvailableDate: null,
              earliestAvailableTime: null,
            },
      },
      //
      {
        type: "CTA",
        value: {
          actions: [
            {
              label: "Book",
              action: "BOOK",
              payload: {
                center_id: item.center.id,
                modality_id: item.modality.id,
                test_config_id: item.test.id,
              },
            },
          ],
        },
      },
    ],
  }));

  return {
    cards,
    meta: {
      total_results: results.length,
      returned: cards.length,
    },
  };
}

(async () => {
  const response = await searchService({
    modality: "",
    test_keyword: "plain",
    sort: [{ by: "PRICE", order: "ASC" }],
    limit: 2,
  });

  console.log(JSON.stringify(response, null, 2));
})();