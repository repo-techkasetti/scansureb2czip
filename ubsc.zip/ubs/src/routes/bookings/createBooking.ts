import Razorpay from "razorpay"
import { prisma } from "../../lib/prisma"
import { Request, Response } from "express"

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY!,
  key_secret: process.env.RAZORPAY_SECRET!
})

export const createBooking = async (req: Request, res: Response) => {
  try {

    const {
      centerId,
      modalityId,
      testConfigId,
      date,
      slot,
      patientId
    } = req.body

    // Fetch test configuration
    const test = await prisma.modalityTestConfig.findUnique({
      where: { id: testConfigId }
    })

    if (!test) {
      return res.status(404).json({
        message: "Test config not found"
      })
    }

    const price = test.price

    // Fetch patient
    const patient = await prisma.patient.findUnique({
      where: { id: patientId }
    })

    if (!patient) {
      return res.status(404).json({
        message: "Patient not found"
      })
    }

    if (!patient.createdByUserId) {
      return res.status(400).json({
        message: "Patient not linked to a user"
      })
    }

    // Create appointment
    const appointment = await prisma.appointment.create({
      data: {
        userId: patient.createdByUserId,
        familyId: patient.familyId,
        centerId,
        modalityId,
        testConfigId,
        patientId,
        machineId: "mach1",
        operatorId: "op1",
        appointmentDate: new Date(date),
        startTime: new Date(`${date}T${slot}:00`),
        endTime: new Date(`${date}T${slot}:00`),
        status: "HOLD",
        holdExpiresAt: new Date(Date.now() + 5 * 60 * 1000)
      }
    })

    // Create Razorpay order
    const order = await razorpay.orders.create({
      amount: price * 100,
      currency: "INR",
      receipt: appointment.id
    })

    // Save payment record
    await prisma.payment.create({
      data: {
        appointmentId: appointment.id,
        razorpayOrderId: order.id,
        amount: price,
        status: "CREATED"
      }
    })

    res.json({
      appointmentId: appointment.id,
      orderId: order.id,
      amount: price
    })

  } catch (error) {
    console.error(error)
    res.status(500).json({
      message: "Booking creation failed"
    })
  }
}