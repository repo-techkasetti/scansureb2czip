import { Request, Response } from "express"
import { prisma } from "../../lib/prisma"

export const createPatient = async (req: Request, res: Response) => {

  const userId = req.userId!

  const {
    name,
    relation,
    gender,
    dateOfBirth
  } = req.body

  const user = await prisma.userAccount.findUnique({
    where: { id: userId }
  })

  if (!user?.primaryFamilyId) {
    return res.status(400).json({
      message: "Family not found"
    })
  }

  const patient = await prisma.patient.create({
    data: {
      name,
      relation,
      gender,
      familyId: user.primaryFamilyId,
      createdByUserId: userId,
      dateOfBirth: dateOfBirth
        ? new Date(dateOfBirth)
        : null
    }
  })

  res.json(patient)
}