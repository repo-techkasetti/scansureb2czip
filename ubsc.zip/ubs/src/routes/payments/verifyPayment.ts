import { Request, Response } from "express"
import crypto from "crypto"
import { prisma } from "../../lib/prisma"

export const verifyPayment = async (req: Request, res: Response) => {

  try {

    const {
      appointmentId,
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature
    } = req.body

    // Create signature for verification
    const body = razorpay_order_id + "|" + razorpay_payment_id

    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_SECRET!)
      .update(body.toString())
      .digest("hex")

    // Check signature
    if (expectedSignature !== razorpay_signature) {
      return res.status(400).json({
        message: "Invalid payment signature"
      })
    }

    // Update payment table
    await prisma.payment.updateMany({
      where: {
        appointmentId: appointmentId
      },
      data: {
        razorpayPaymentId: razorpay_payment_id,
        razorpaySignature: razorpay_signature,
        status: "SUCCESS"
      }
    })

    // Update appointment
    await prisma.appointment.update({
      where: {
        id: appointmentId
      },
      data: {
        status: "BOOKED"
      }
    })

    res.json({
      success: true,
      message: "Booking confirmed"
    })

  } catch (error) {

    console.error("Payment verify error:", error)

    res.status(500).json({
      message: "Payment verification failed"
    })
  }
}