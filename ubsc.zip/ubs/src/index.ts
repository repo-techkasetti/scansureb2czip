import { prisma } from './lib/prisma.js'

async function main() {
  const centers = await prisma.center.findMany()
  console.log(centers)
}

main()
  .finally(async () => {
    await prisma.$disconnect()
  })