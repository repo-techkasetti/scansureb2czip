import { getBookingAvailableSlots } from "./availableSlots.js"

async function test() {
  const result = await getBookingAvailableSlots({
    centerId: "c2",
    modalityId: "ct",
    testConfigId: "tc3",
    days: 16
  })

  console.log(JSON.stringify(result, null, 2))
}

test()
  .then(() => process.exit(0))
  .catch(err => {
    console.error(err)
    process.exit(1)
  })