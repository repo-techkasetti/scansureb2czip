import { getCenterDetail } from "./centerDetail"

async function test() {
  const result = await getCenterDetail(
     "c2"
  )

  console.log(JSON.stringify(result, null, 2))
}

test()
  .then(() => process.exit(0))
  .catch(err => {
    console.error(err)
    process.exit(1)
  })