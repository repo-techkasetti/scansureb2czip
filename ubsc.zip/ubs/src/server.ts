import express from "express";
import cors from "cors";
import searchService from "./services/search.service.js";
import bookingRouter from "./routes/booking.js";
import centerDetailRouter from "./routes/centerDetail.js";
// import { createBooking } from "./routes/bookings/createBooking"//just test
import { createBooking } from "./controllers/bookingController"
import { verifyPayment } from "./routes/payments/verifyPayment"
//
import { sendOtp } from "./routes/auth/sendOtp"
import { verifyOtp } from "./routes/auth/verifyOtp"
import { getPatients } from "./routes/patients/getPatients"
import { createPatient } from "./routes/patients/createPatient"
import { authMiddleware } from "./middleware/authMiddleware"
//
import { createProxyMiddleware } from "http-proxy-middleware";
//

const app = express();

app.use(cors());
app.use(express.json());

//
app.use(
  "/pat",
  createProxyMiddleware({
    target: "http://localhost:3001",
    changeOrigin: true
  })
);
//


//
app.use("/booking", bookingRouter)
app.use("/center", centerDetailRouter)
app.post("/api/bookings/create", createBooking)//just test
app.post("/api/payment/verify", verifyPayment)
//
// AUTH
app.post("/api/auth/send-otp", sendOtp)
app.post("/api/auth/verify-otp", verifyOtp)

// PATIENT
app.get("/api/patients", authMiddleware, getPatients)
app.post("/api/patients", authMiddleware, createPatient)
//

// ✅ API ROUTE
app.post("/api/search", async (req, res) => {
  try {
    const payload = req.body ?? {}; // SAFE

    const result = await searchService(payload);

    res.json(result);
  } catch (error) {
    console.error("Search Error:", error);
    res.status(500).json({
      message: "Search failed",
    });
  }
});


const PORT = 3000;

app.listen(PORT, "0.0.0.0",() => {
  console.log(`🚀 Server running at http://${process.env.IP_ADDRESS}:${PORT}`);
});
// app.listen(PORT, () => {
//   console.log(`🚀 Server running at http://localhost:${PORT}`);
// });