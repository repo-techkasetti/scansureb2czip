import { getAvailabilitySummary } from "./avlsummary"

async function run() {

  const result = await getAvailabilitySummary({
    centerId: "c1",
    // centerId: "42698ce3-7700-47a3-9040-cb3476a37fd5",
    // modalityId: "11465eae-e0ea-4eec-8b16-c9b351c04d9f",
    // date: new Date().toISOString().split("T")[0]
    startDate: "2026-02-21",
    endDate: "2026-02-23",
  })

  console.log(result)
}

run()