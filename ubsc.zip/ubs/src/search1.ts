import { prisma } from "./lib/prisma.js"
import { getAvailabilitySummary } from "../src/avlsummary.js"

type SortOption = {
  by: "PRICE" | "RATING" | "DISTANCE" | "EARLIEST_AVAILABLE";
  order: "ASC" | "DESC";
};

type SearchPayload = {
  location?: { lat: number; lng: number; radius_km?: number } | null;
  modality?: string | null;
  test_keyword?: string | null;
  preferred_date?: string | null;
  search_window_days?: number;
  sort?: SortOption[];
  limit?: number;
};

function buildDateRange(
  preferredDate: string,
  windowDays: number
) {
  const start = new Date(preferredDate);
  const end = new Date(preferredDate);

  end.setDate(end.getDate() + windowDays - 1);

  return {
    startDate: start.toISOString(),
    endDate: end.toISOString(),
  };
}

async function searchService(rawPayload: SearchPayload) {
  const today = new Date().toISOString().split("T")[0];

  const preferred_date = rawPayload.preferred_date ?? today;
  const search_window_days = rawPayload.search_window_days ?? 3;

  const sort =
    rawPayload.sort && rawPayload.sort.length > 0
      ? rawPayload.sort
      : [{ by: "DISTANCE", order: "ASC" }];

  const limit = rawPayload.limit ?? 20;

  const { startDate, endDate } = buildDateRange(
    preferred_date,
    search_window_days
  );

  const centers = await prisma.center.findMany({
    where: {
      isActive: true,
      isDeleted: false,
      modalities: {
        some: {
          isActive: true,
          modality: {
            isActive: true,
            ...(rawPayload.modality && {
              code: rawPayload.modality,
            }),
            testConfigs: {
              some: {
                isDeleted: false,
                ...(rawPayload.test_keyword && {
                  testKeyword: {
                    contains: rawPayload.test_keyword.toUpperCase(),
                    mode: "insensitive",
                  },
                }),
              },
            },
          },
        },
      },
    },
    include: {
      modalities: {
        where: { isActive: true },
        include: {
          modality: {
            include: {
              testConfigs: {
                where: { isDeleted: false },
              },
            },
          },
        },
      },
    },
  });

  let results: any[] = [];

  for (const center of centers) {
    for (const cm of center.modalities) {
      const modality = cm.modality;

      if (rawPayload.modality && modality.code !== rawPayload.modality)
        continue;

      for (const test of modality.testConfigs) {
        if (
          rawPayload.test_keyword &&
          !test.testKeyword
            .toLowerCase()
            .includes(rawPayload.test_keyword.toLowerCase())
        )
          continue;

        const availability = await getAvailabilitySummary({
          centerId: center.id,
          modalityId: modality.id,
          testKeyword: test.testKeyword,
          startDate,
          endDate,
        });

        if (availability.totalAvailableSlots === 0) continue;

        results.push({
          center,
          modality,
          test,
          availability,
        });
      }
    }
  }

  const { by, order } = sort[0];

  results.sort((a, b) => {
    let valA = 0;
    let valB = 0;

    if (by === "PRICE") {
      valA = a.test.price;
      valB = b.test.price;
    }

    if (by === "RATING") {
      valA = a.center.rating;
      valB = b.center.rating;
    }

    if (by === "EARLIEST_AVAILABLE") {
      valA = new Date(a.availability.firstAvailableDate || 0).getTime();
      valB = new Date(b.availability.firstAvailableDate || 0).getTime();
    }

    return order === "ASC" ? valA - valB : valB - valA;
  });

  const limited = results.slice(0, limit);

  const cards = limited.map((item) => ({
    id: `${item.center.id}|${item.modality.id}|${item.test.id}`,
    sections: [
      { type: "TITLE", value: { text: item.center.name } },
      {
        type: "SUBTITLE",
        value: { text: `${item.modality.code} ${item.test.testKeyword}` },
      },
      { type: "META", value: { text: item.center.address } },
      {
        type: "METRICS",
        value: { items: [{ label: "Rating", value: item.center.rating }] },
      },
      {
        type: "PRICE",
        value: {
          display: `Starting at ₹${item.test.price}`,
          min_price: item.test.price,
          currency: "INR",
        },
      },
      {
        type: "AVAILABILITY",
        value: item.availability,
      },
      {
        type: "CTA",
        value: {
          actions: [
            {
              label: "Book",
              action: "BOOK",
              payload: {
                center_id: item.center.id,
                modality_id: item.modality.id,
                test_config_id: item.test.id,
              },
            },
          ],
        },
      },
    ],
  }));

  return {
    cards,
    meta: {
      total_results: results.length,
      returned: cards.length,
      search_window_days,
      preferred_date,
    },
  };
}

(async () => {
  const response = await searchService({
  
  });

  console.log(JSON.stringify(response, null, 2));
})();
