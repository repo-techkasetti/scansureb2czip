-- AlterTable
ALTER TABLE "Appointment" ADD COLUMN     "patientId" TEXT;
