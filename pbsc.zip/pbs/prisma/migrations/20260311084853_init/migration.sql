-- CreateTable
CREATE TABLE "Patient" (
    "upi_id" TEXT NOT NULL,
    "aadhaar_no" TEXT NOT NULL,
    "name" TEXT,
    "phone" TEXT,
    "gender" TEXT,
    "dob" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Patient_pkey" PRIMARY KEY ("upi_id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Patient_aadhaar_no_key" ON "Patient"("aadhaar_no");
