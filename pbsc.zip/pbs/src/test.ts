import { prisma } from './lib/prisma.js'

async function main() {
  const patients = await prisma.patient.findMany()
  console.log('patients: ', patients)
}

main()
  .finally(async () => {
    await prisma.$disconnect()
  })