import express from "express";
import cors from "cors";

import { getPatientByUpi } from "./routes/getPatientByUpi";
import { getPatientByAadhar } from "./routes/getPatientByAadhar";
import { registerPatient } from "./routes/registerPatient";


const app = express();

app.use(cors());
app.use(express.json());


// GET patient by UPI ID
app.get("/api/patient/:upi_id", getPatientByUpi);
// GET patient by Aadhaar
app.get("/api/patient/aadhaar/:aadhaar", getPatientByAadhar);
// Register patient
app.post("/api/patient/register", registerPatient);


const PORT = 3001;

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://${process.env.IP_ADDRESS}:${PORT}`);
});

//npx tsx src/server.ts